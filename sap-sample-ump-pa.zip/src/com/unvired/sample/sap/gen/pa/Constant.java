//	Generated using Unvired Modeller - Build R-4.000.0094
package com.unvired.sample.sap.gen.pa;

public class Constant 
{
	public static final String PA_CREATE_PERSON = "UNVIREDSAPSAMPLE_PA_CREATE_PERSON";
	public static final String PA_GET_PERSON = "UNVIREDSAPSAMPLE_PA_GET_PERSON";
	public static final String MEREP_CONTACT_CREATE = "UNVIREDSAPSAMPLE_MEREP_CONTACT_CREATE";
	public static final String MEREP_CONTACT_GETDETAIL = "UNVIREDSAPSAMPLE_MEREP_CONTACT_GETDETAIL";


}
